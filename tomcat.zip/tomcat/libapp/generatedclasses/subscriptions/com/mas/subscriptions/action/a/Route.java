
package com.mas.subscriptions.action.a;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "atis_id",
    "code",
    "description",
    "line",
    "penta_id",
    "ref_id",
    "rt"
})
public class Route {

    @JsonProperty("atis_id")
    private String atisId;
    @JsonProperty("code")
    private String code;
    @JsonProperty("description")
    private String description;
    @JsonProperty("line")
    private String line;
    @JsonProperty("penta_id")
    private String pentaId;
    @JsonProperty("ref_id")
    private String refId;
    @JsonProperty("rt")
    private String rt;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("atis_id")
    public String getAtisId() {
        return atisId;
    }

    @JsonProperty("atis_id")
    public void setAtisId(String atisId) {
        this.atisId = atisId;
    }

    public Route withAtisId(String atisId) {
        this.atisId = atisId;
        return this;
    }

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    public Route withCode(String code) {
        this.code = code;
        return this;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    public Route withDescription(String description) {
        this.description = description;
        return this;
    }

    @JsonProperty("line")
    public String getLine() {
        return line;
    }

    @JsonProperty("line")
    public void setLine(String line) {
        this.line = line;
    }

    public Route withLine(String line) {
        this.line = line;
        return this;
    }

    @JsonProperty("penta_id")
    public String getPentaId() {
        return pentaId;
    }

    @JsonProperty("penta_id")
    public void setPentaId(String pentaId) {
        this.pentaId = pentaId;
    }

    public Route withPentaId(String pentaId) {
        this.pentaId = pentaId;
        return this;
    }

    @JsonProperty("ref_id")
    public String getRefId() {
        return refId;
    }

    @JsonProperty("ref_id")
    public void setRefId(String refId) {
        this.refId = refId;
    }

    public Route withRefId(String refId) {
        this.refId = refId;
        return this;
    }

    @JsonProperty("rt")
    public String getRt() {
        return rt;
    }

    @JsonProperty("rt")
    public void setRt(String rt) {
        this.rt = rt;
    }

    public Route withRt(String rt) {
        this.rt = rt;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Route withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Route.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("atisId");
        sb.append('=');
        sb.append(((this.atisId == null)?"<null>":this.atisId));
        sb.append(',');
        sb.append("code");
        sb.append('=');
        sb.append(((this.code == null)?"<null>":this.code));
        sb.append(',');
        sb.append("description");
        sb.append('=');
        sb.append(((this.description == null)?"<null>":this.description));
        sb.append(',');
        sb.append("line");
        sb.append('=');
        sb.append(((this.line == null)?"<null>":this.line));
        sb.append(',');
        sb.append("pentaId");
        sb.append('=');
        sb.append(((this.pentaId == null)?"<null>":this.pentaId));
        sb.append(',');
        sb.append("refId");
        sb.append('=');
        sb.append(((this.refId == null)?"<null>":this.refId));
        sb.append(',');
        sb.append("rt");
        sb.append('=');
        sb.append(((this.rt == null)?"<null>":this.rt));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.atisId == null)? 0 :this.atisId.hashCode()));
        result = ((result* 31)+((this.rt == null)? 0 :this.rt.hashCode()));
        result = ((result* 31)+((this.code == null)? 0 :this.code.hashCode()));
        result = ((result* 31)+((this.line == null)? 0 :this.line.hashCode()));
        result = ((result* 31)+((this.pentaId == null)? 0 :this.pentaId.hashCode()));
        result = ((result* 31)+((this.description == null)? 0 :this.description.hashCode()));
        result = ((result* 31)+((this.refId == null)? 0 :this.refId.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Route) == false) {
            return false;
        }
        Route rhs = ((Route) other);
        return (((((((((this.atisId == rhs.atisId)||((this.atisId!= null)&&this.atisId.equals(rhs.atisId)))&&((this.rt == rhs.rt)||((this.rt!= null)&&this.rt.equals(rhs.rt))))&&((this.code == rhs.code)||((this.code!= null)&&this.code.equals(rhs.code))))&&((this.line == rhs.line)||((this.line!= null)&&this.line.equals(rhs.line))))&&((this.pentaId == rhs.pentaId)||((this.pentaId!= null)&&this.pentaId.equals(rhs.pentaId))))&&((this.description == rhs.description)||((this.description!= null)&&this.description.equals(rhs.description))))&&((this.refId == rhs.refId)||((this.refId!= null)&&this.refId.equals(rhs.refId))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))));
    }

}
