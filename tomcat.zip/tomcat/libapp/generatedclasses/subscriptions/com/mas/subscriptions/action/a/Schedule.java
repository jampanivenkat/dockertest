
package com.mas.subscriptions.action.a;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "fr_atis_id",
    "fr_code",
    "fr_description",
    "fr_lattitude",
    "fr_line_code",
    "fr_longitude",
    "fr_penta_ID",
    "fr_stop_id",
    "ref_id",
    "to_atis_id",
    "to_code",
    "to_description",
    "to_lattitude",
    "to_line_code",
    "to_longitude",
    "to_penta_id",
    "to_stop_id"
})
public class Schedule {

    @JsonProperty("fr_atis_id")
    private String frAtisId;
    @JsonProperty("fr_code")
    private String frCode;
    @JsonProperty("fr_description")
    private String frDescription;
    @JsonProperty("fr_lattitude")
    private String frLattitude;
    @JsonProperty("fr_line_code")
    private String frLineCode;
    @JsonProperty("fr_longitude")
    private String frLongitude;
    @JsonProperty("fr_penta_ID")
    private String frPentaID;
    @JsonProperty("fr_stop_id")
    private String frStopId;
    @JsonProperty("ref_id")
    private String refId;
    @JsonProperty("to_atis_id")
    private String toAtisId;
    @JsonProperty("to_code")
    private String toCode;
    @JsonProperty("to_description")
    private String toDescription;
    @JsonProperty("to_lattitude")
    private String toLattitude;
    @JsonProperty("to_line_code")
    private String toLineCode;
    @JsonProperty("to_longitude")
    private String toLongitude;
    @JsonProperty("to_penta_id")
    private String toPentaId;
    @JsonProperty("to_stop_id")
    private String toStopId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("fr_atis_id")
    public String getFrAtisId() {
        return frAtisId;
    }

    @JsonProperty("fr_atis_id")
    public void setFrAtisId(String frAtisId) {
        this.frAtisId = frAtisId;
    }

    public Schedule withFrAtisId(String frAtisId) {
        this.frAtisId = frAtisId;
        return this;
    }

    @JsonProperty("fr_code")
    public String getFrCode() {
        return frCode;
    }

    @JsonProperty("fr_code")
    public void setFrCode(String frCode) {
        this.frCode = frCode;
    }

    public Schedule withFrCode(String frCode) {
        this.frCode = frCode;
        return this;
    }

    @JsonProperty("fr_description")
    public String getFrDescription() {
        return frDescription;
    }

    @JsonProperty("fr_description")
    public void setFrDescription(String frDescription) {
        this.frDescription = frDescription;
    }

    public Schedule withFrDescription(String frDescription) {
        this.frDescription = frDescription;
        return this;
    }

    @JsonProperty("fr_lattitude")
    public String getFrLattitude() {
        return frLattitude;
    }

    @JsonProperty("fr_lattitude")
    public void setFrLattitude(String frLattitude) {
        this.frLattitude = frLattitude;
    }

    public Schedule withFrLattitude(String frLattitude) {
        this.frLattitude = frLattitude;
        return this;
    }

    @JsonProperty("fr_line_code")
    public String getFrLineCode() {
        return frLineCode;
    }

    @JsonProperty("fr_line_code")
    public void setFrLineCode(String frLineCode) {
        this.frLineCode = frLineCode;
    }

    public Schedule withFrLineCode(String frLineCode) {
        this.frLineCode = frLineCode;
        return this;
    }

    @JsonProperty("fr_longitude")
    public String getFrLongitude() {
        return frLongitude;
    }

    @JsonProperty("fr_longitude")
    public void setFrLongitude(String frLongitude) {
        this.frLongitude = frLongitude;
    }

    public Schedule withFrLongitude(String frLongitude) {
        this.frLongitude = frLongitude;
        return this;
    }

    @JsonProperty("fr_penta_ID")
    public String getFrPentaID() {
        return frPentaID;
    }

    @JsonProperty("fr_penta_ID")
    public void setFrPentaID(String frPentaID) {
        this.frPentaID = frPentaID;
    }

    public Schedule withFrPentaID(String frPentaID) {
        this.frPentaID = frPentaID;
        return this;
    }

    @JsonProperty("fr_stop_id")
    public String getFrStopId() {
        return frStopId;
    }

    @JsonProperty("fr_stop_id")
    public void setFrStopId(String frStopId) {
        this.frStopId = frStopId;
    }

    public Schedule withFrStopId(String frStopId) {
        this.frStopId = frStopId;
        return this;
    }

    @JsonProperty("ref_id")
    public String getRefId() {
        return refId;
    }

    @JsonProperty("ref_id")
    public void setRefId(String refId) {
        this.refId = refId;
    }

    public Schedule withRefId(String refId) {
        this.refId = refId;
        return this;
    }

    @JsonProperty("to_atis_id")
    public String getToAtisId() {
        return toAtisId;
    }

    @JsonProperty("to_atis_id")
    public void setToAtisId(String toAtisId) {
        this.toAtisId = toAtisId;
    }

    public Schedule withToAtisId(String toAtisId) {
        this.toAtisId = toAtisId;
        return this;
    }

    @JsonProperty("to_code")
    public String getToCode() {
        return toCode;
    }

    @JsonProperty("to_code")
    public void setToCode(String toCode) {
        this.toCode = toCode;
    }

    public Schedule withToCode(String toCode) {
        this.toCode = toCode;
        return this;
    }

    @JsonProperty("to_description")
    public String getToDescription() {
        return toDescription;
    }

    @JsonProperty("to_description")
    public void setToDescription(String toDescription) {
        this.toDescription = toDescription;
    }

    public Schedule withToDescription(String toDescription) {
        this.toDescription = toDescription;
        return this;
    }

    @JsonProperty("to_lattitude")
    public String getToLattitude() {
        return toLattitude;
    }

    @JsonProperty("to_lattitude")
    public void setToLattitude(String toLattitude) {
        this.toLattitude = toLattitude;
    }

    public Schedule withToLattitude(String toLattitude) {
        this.toLattitude = toLattitude;
        return this;
    }

    @JsonProperty("to_line_code")
    public String getToLineCode() {
        return toLineCode;
    }

    @JsonProperty("to_line_code")
    public void setToLineCode(String toLineCode) {
        this.toLineCode = toLineCode;
    }

    public Schedule withToLineCode(String toLineCode) {
        this.toLineCode = toLineCode;
        return this;
    }

    @JsonProperty("to_longitude")
    public String getToLongitude() {
        return toLongitude;
    }

    @JsonProperty("to_longitude")
    public void setToLongitude(String toLongitude) {
        this.toLongitude = toLongitude;
    }

    public Schedule withToLongitude(String toLongitude) {
        this.toLongitude = toLongitude;
        return this;
    }

    @JsonProperty("to_penta_id")
    public String getToPentaId() {
        return toPentaId;
    }

    @JsonProperty("to_penta_id")
    public void setToPentaId(String toPentaId) {
        this.toPentaId = toPentaId;
    }

    public Schedule withToPentaId(String toPentaId) {
        this.toPentaId = toPentaId;
        return this;
    }

    @JsonProperty("to_stop_id")
    public String getToStopId() {
        return toStopId;
    }

    @JsonProperty("to_stop_id")
    public void setToStopId(String toStopId) {
        this.toStopId = toStopId;
    }

    public Schedule withToStopId(String toStopId) {
        this.toStopId = toStopId;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Schedule withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Schedule.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("frAtisId");
        sb.append('=');
        sb.append(((this.frAtisId == null)?"<null>":this.frAtisId));
        sb.append(',');
        sb.append("frCode");
        sb.append('=');
        sb.append(((this.frCode == null)?"<null>":this.frCode));
        sb.append(',');
        sb.append("frDescription");
        sb.append('=');
        sb.append(((this.frDescription == null)?"<null>":this.frDescription));
        sb.append(',');
        sb.append("frLattitude");
        sb.append('=');
        sb.append(((this.frLattitude == null)?"<null>":this.frLattitude));
        sb.append(',');
        sb.append("frLineCode");
        sb.append('=');
        sb.append(((this.frLineCode == null)?"<null>":this.frLineCode));
        sb.append(',');
        sb.append("frLongitude");
        sb.append('=');
        sb.append(((this.frLongitude == null)?"<null>":this.frLongitude));
        sb.append(',');
        sb.append("frPentaID");
        sb.append('=');
        sb.append(((this.frPentaID == null)?"<null>":this.frPentaID));
        sb.append(',');
        sb.append("frStopId");
        sb.append('=');
        sb.append(((this.frStopId == null)?"<null>":this.frStopId));
        sb.append(',');
        sb.append("refId");
        sb.append('=');
        sb.append(((this.refId == null)?"<null>":this.refId));
        sb.append(',');
        sb.append("toAtisId");
        sb.append('=');
        sb.append(((this.toAtisId == null)?"<null>":this.toAtisId));
        sb.append(',');
        sb.append("toCode");
        sb.append('=');
        sb.append(((this.toCode == null)?"<null>":this.toCode));
        sb.append(',');
        sb.append("toDescription");
        sb.append('=');
        sb.append(((this.toDescription == null)?"<null>":this.toDescription));
        sb.append(',');
        sb.append("toLattitude");
        sb.append('=');
        sb.append(((this.toLattitude == null)?"<null>":this.toLattitude));
        sb.append(',');
        sb.append("toLineCode");
        sb.append('=');
        sb.append(((this.toLineCode == null)?"<null>":this.toLineCode));
        sb.append(',');
        sb.append("toLongitude");
        sb.append('=');
        sb.append(((this.toLongitude == null)?"<null>":this.toLongitude));
        sb.append(',');
        sb.append("toPentaId");
        sb.append('=');
        sb.append(((this.toPentaId == null)?"<null>":this.toPentaId));
        sb.append(',');
        sb.append("toStopId");
        sb.append('=');
        sb.append(((this.toStopId == null)?"<null>":this.toStopId));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.toLineCode == null)? 0 :this.toLineCode.hashCode()));
        result = ((result* 31)+((this.toLattitude == null)? 0 :this.toLattitude.hashCode()));
        result = ((result* 31)+((this.frLineCode == null)? 0 :this.frLineCode.hashCode()));
        result = ((result* 31)+((this.toDescription == null)? 0 :this.toDescription.hashCode()));
        result = ((result* 31)+((this.toCode == null)? 0 :this.toCode.hashCode()));
        result = ((result* 31)+((this.toAtisId == null)? 0 :this.toAtisId.hashCode()));
        result = ((result* 31)+((this.frCode == null)? 0 :this.frCode.hashCode()));
        result = ((result* 31)+((this.toStopId == null)? 0 :this.toStopId.hashCode()));
        result = ((result* 31)+((this.frPentaID == null)? 0 :this.frPentaID.hashCode()));
        result = ((result* 31)+((this.toLongitude == null)? 0 :this.toLongitude.hashCode()));
        result = ((result* 31)+((this.frLattitude == null)? 0 :this.frLattitude.hashCode()));
        result = ((result* 31)+((this.toPentaId == null)? 0 :this.toPentaId.hashCode()));
        result = ((result* 31)+((this.frLongitude == null)? 0 :this.frLongitude.hashCode()));
        result = ((result* 31)+((this.frAtisId == null)? 0 :this.frAtisId.hashCode()));
        result = ((result* 31)+((this.refId == null)? 0 :this.refId.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.frStopId == null)? 0 :this.frStopId.hashCode()));
        result = ((result* 31)+((this.frDescription == null)? 0 :this.frDescription.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Schedule) == false) {
            return false;
        }
        Schedule rhs = ((Schedule) other);
        return (((((((((((((((((((this.toLineCode == rhs.toLineCode)||((this.toLineCode!= null)&&this.toLineCode.equals(rhs.toLineCode)))&&((this.toLattitude == rhs.toLattitude)||((this.toLattitude!= null)&&this.toLattitude.equals(rhs.toLattitude))))&&((this.frLineCode == rhs.frLineCode)||((this.frLineCode!= null)&&this.frLineCode.equals(rhs.frLineCode))))&&((this.toDescription == rhs.toDescription)||((this.toDescription!= null)&&this.toDescription.equals(rhs.toDescription))))&&((this.toCode == rhs.toCode)||((this.toCode!= null)&&this.toCode.equals(rhs.toCode))))&&((this.toAtisId == rhs.toAtisId)||((this.toAtisId!= null)&&this.toAtisId.equals(rhs.toAtisId))))&&((this.frCode == rhs.frCode)||((this.frCode!= null)&&this.frCode.equals(rhs.frCode))))&&((this.toStopId == rhs.toStopId)||((this.toStopId!= null)&&this.toStopId.equals(rhs.toStopId))))&&((this.frPentaID == rhs.frPentaID)||((this.frPentaID!= null)&&this.frPentaID.equals(rhs.frPentaID))))&&((this.toLongitude == rhs.toLongitude)||((this.toLongitude!= null)&&this.toLongitude.equals(rhs.toLongitude))))&&((this.frLattitude == rhs.frLattitude)||((this.frLattitude!= null)&&this.frLattitude.equals(rhs.frLattitude))))&&((this.toPentaId == rhs.toPentaId)||((this.toPentaId!= null)&&this.toPentaId.equals(rhs.toPentaId))))&&((this.frLongitude == rhs.frLongitude)||((this.frLongitude!= null)&&this.frLongitude.equals(rhs.frLongitude))))&&((this.frAtisId == rhs.frAtisId)||((this.frAtisId!= null)&&this.frAtisId.equals(rhs.frAtisId))))&&((this.refId == rhs.refId)||((this.refId!= null)&&this.refId.equals(rhs.refId))))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.frStopId == rhs.frStopId)||((this.frStopId!= null)&&this.frStopId.equals(rhs.frStopId))))&&((this.frDescription == rhs.frDescription)||((this.frDescription!= null)&&this.frDescription.equals(rhs.frDescription))));
    }

}
