
package com.mas.subscriptions.action.a;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BUS",
    "LR",
    "RAIL"
})
public class Favorites {

    @JsonProperty("BUS")
    private Bus bus;
    @JsonProperty("LR")
    private Lr lr;
    @JsonProperty("RAIL")
    private Rail rail;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("BUS")
    public Bus getBus() {
        return bus;
    }

    @JsonProperty("BUS")
    public void setBus(Bus bus) {
        this.bus = bus;
    }

    public Favorites withBus(Bus bus) {
        this.bus = bus;
        return this;
    }

    @JsonProperty("LR")
    public Lr getLr() {
        return lr;
    }

    @JsonProperty("LR")
    public void setLr(Lr lr) {
        this.lr = lr;
    }

    public Favorites withLr(Lr lr) {
        this.lr = lr;
        return this;
    }

    @JsonProperty("RAIL")
    public Rail getRail() {
        return rail;
    }

    @JsonProperty("RAIL")
    public void setRail(Rail rail) {
        this.rail = rail;
    }

    public Favorites withRail(Rail rail) {
        this.rail = rail;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Favorites withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Favorites.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("bus");
        sb.append('=');
        sb.append(((this.bus == null)?"<null>":this.bus));
        sb.append(',');
        sb.append("lr");
        sb.append('=');
        sb.append(((this.lr == null)?"<null>":this.lr));
        sb.append(',');
        sb.append("rail");
        sb.append('=');
        sb.append(((this.rail == null)?"<null>":this.rail));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.bus == null)? 0 :this.bus.hashCode()));
        result = ((result* 31)+((this.additionalProperties == null)? 0 :this.additionalProperties.hashCode()));
        result = ((result* 31)+((this.lr == null)? 0 :this.lr.hashCode()));
        result = ((result* 31)+((this.rail == null)? 0 :this.rail.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Favorites) == false) {
            return false;
        }
        Favorites rhs = ((Favorites) other);
        return (((((this.bus == rhs.bus)||((this.bus!= null)&&this.bus.equals(rhs.bus)))&&((this.additionalProperties == rhs.additionalProperties)||((this.additionalProperties!= null)&&this.additionalProperties.equals(rhs.additionalProperties))))&&((this.lr == rhs.lr)||((this.lr!= null)&&this.lr.equals(rhs.lr))))&&((this.rail == rhs.rail)||((this.rail!= null)&&this.rail.equals(rhs.rail))));
    }

}
